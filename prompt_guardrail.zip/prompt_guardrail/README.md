# Prompt Guardrail

A Flutter mobile application for testing AI prompt validation and security guardrails in a telco network context. The app allows users to test predefined prompts against validation rules and view detailed security scan results.

## Features

### Core Functionality
- **Dual Mode System**: Mock mode for testing without API costs, Real mode for live Gemini API integration
- **Categorized Prompts**: Valid and invalid prompts organized by categories (network queries, troubleshooting, vague, harmful, etc.)
- **Chat Interface**: Modern messaging UI showing user prompts and validation responses
- **Security Scans**: View detailed input/output scan results for each prompt
- **Session Management**: Start new sessions to clear chat history
- **Authentication**: Login system with configurable credentials

### Mobile-Optimized
- Bottom sheet prompt selector
- Swipeable, draggable modals
- Touch-friendly buttons
- Responsive layout
- SafeArea support for notches

## Screenshots

[Add screenshots here]

## Getting Started

### Prerequisites
- Flutter SDK (3.0.0 or higher)
- Dart SDK
- For Real mode: Google Gemini API key

### Installation

1. Clone the repository:
```bash
git clone <repository-url>
cd prompt_guardrail
```

2. Install dependencies:
```bash
flutter pub get
```

3. Run the app:
```bash
flutter run
```

## Configuration

All app behavior is controlled via JSON configuration files. No code changes needed!

### 1. App Configuration (`assets/config/app_config.json`)

```json
{
  "mode": "mock",
  "api_key": "",
  "model": "gemini-pro",
  "timeout_seconds": 30,
  "auth": {
    "username": "admin",
    "password": "password123"
  }
}
```

**Fields:**
- `mode`: "mock" or "real"
- `api_key`: Your Gemini API key (required for real mode)
- `model`: Gemini model name
- `timeout_seconds`: API timeout
- `auth`: Login credentials

### 2. Prompts Configuration (`assets/data/prompts.json`)

```json
{
  "valid_prompts": {
    "category_name": [
      {
        "name": "Display Name",
        "prompt": "Actual prompt text to send"
      }
    ]
  },
  "invalid_prompts": {
    "threat_category": [
      {
        "name": "Display Name",
        "prompt": "Actual prompt text to send"
      }
    ]
  },
  "prompt_responses": {
    "Actual prompt text": {
      "valid": true,
      "message": "Validation message",
      "response": "Mock API response"
    }
  }
}
```

**Structure:**
- `name`: Displayed in the menu
- `prompt`: Actual text sent to API
- Categories: Group prompts by type (network_queries, troubleshooting, vague, harmful, etc.)

### 3. Mock Responses (`assets/data/mock_responses.json`)

```json
{
  "mock_responses": [
    {
      "valid": true,
      "message": "Prompt is valid",
      "response": "Simulated API response"
    }
  ],
  "invalid_response": {
    "valid": false,
    "message": "Prompt validation failed",
    "response": "Request blocked message"
  }
}
```

## Usage

### Basic Workflow

1. **Login**: Enter credentials (default: admin/password123)
2. **Select Prompt**: Tap "Select Prompt" button
3. **Choose Category**: Browse Valid or Invalid tabs
4. **Pick Prompt**: Tap a prompt from the categorized list
5. **View Response**: See validation result and response
6. **Security Scans**: Tap "Security Scans" to view input/output details
7. **New Session**: Tap "New Session" to clear chat history

### Switching Modes

**To switch from Mock to Real mode:**

1. Edit `assets/config/app_config.json`:
```json
{
  "mode": "real",
  "api_key": "YOUR_GEMINI_API_KEY"
}
```

2. Hot restart the app (press `R` in terminal)

**Get Gemini API Key:**
Visit https://makersuite.google.com/app/apikey

## Project Structure

```
lib/
  models/           - Data models (AppConfig, PromptsData, PromptResponse)
  providers/        - Riverpod state management
  repositories/     - Mock and Real API implementations
  services/         - Config loader, Gemini API client
  screens/          - Login and Home screens
  widgets/          - Reusable UI components
assets/
  config/           - App configuration
  data/             - Prompts and mock responses
```

## Architecture

### State Management
- **Riverpod** for reactive state management
- **Repository Pattern** for data abstraction
- **Provider Pattern** for dependency injection

### Key Components

**Providers:**
- `appConfigProvider`: App configuration
- `promptsDataProvider`: Prompt lists
- `chatHistoryProvider`: Conversation history
- `promptResponseProvider`: Current response state

**Repositories:**
- `MockPromptRepository`: Simulated responses
- `RealPromptRepository`: Gemini API integration

**Services:**
- `ConfigService`: Load JSON configurations
- `GeminiApiService`: API client for Gemini

## Customization

### Adding New Prompts

1. Edit `assets/data/prompts.json`
2. Add to appropriate category:
```json
{
  "name": "Check Tower Status",
  "prompt": "What is the status of tower XYZ-123?"
}
```
3. Add response mapping:
```json
"What is the status of tower XYZ-123?": {
  "valid": true,
  "message": "Prompt is valid",
  "response": "Tower XYZ-123 is operational"
}
```
4. Hot restart app

### Creating New Categories

```json
"valid_prompts": {
  "your_new_category": [
    {
      "name": "Prompt Name",
      "prompt": "Prompt text"
    }
  ]
}
```

### Changing Login Credentials

Edit `assets/config/app_config.json`:
```json
"auth": {
  "username": "your_username",
  "password": "your_password"
}
```

## API Integration

### Mock Mode
- Returns predefined responses from `mock_responses.json`
- Simulates 800ms API delay
- No API key required
- Perfect for testing and demos

### Real Mode
- Validates prompts client-side first
- Blocks invalid prompts (no API call)
- Sends valid prompts to Gemini API
- Returns actual AI responses
- Requires API key

### Validation Flow

```
User selects prompt
    ↓
Client-side validation
    ↓
Valid? → Call API → Display response
    ↓
Invalid? → Block request → Show security alert
```

## Security Features

- **Input Validation**: Client-side prompt validation
- **Request Blocking**: Invalid prompts never reach API
- **Security Scans**: Detailed input/output inspection
- **Threat Categories**: Organized by threat type (vague, harmful, nonsense)
- **Audit Trail**: Response timestamps and timing

## Dependencies

```yaml
dependencies:
  flutter_riverpod: ^2.4.9  # State management
  dio: ^5.4.0               # HTTP client
  intl: ^0.18.1             # Date formatting
```

## Troubleshooting

### App won't start
- Run `flutter clean`
- Run `flutter pub get`
- Restart app

### Prompts not updating
- Hot restart (press `R`) instead of hot reload
- JSON files are loaded at startup

### API errors in Real mode
- Check API key in `app_config.json`
- Verify internet connection
- Check Gemini API quota

### Login fails
- Verify credentials in `app_config.json`
- Hot restart after changing config

## Development

### Running in Debug Mode
```bash
flutter run
```

### Building for Release
```bash
# Android
flutter build apk --release

# iOS
flutter build ios --release
```

### Hot Reload
- Press `r` in terminal (reload code changes)
- Press `R` in terminal (restart app, reload assets)

## Testing

The app is designed for testing prompt validation:

1. **Valid Prompts**: Should pass validation and return responses
2. **Invalid Prompts**: Should be blocked with security alerts
3. **Mock Mode**: Test without API costs
4. **Real Mode**: Verify actual API integration

## License

[Add your license here]

## Contributing

[Add contribution guidelines here]

## Support

[Add support information here]

## Acknowledgments

- Built with Flutter
- Uses Google Gemini API
- State management by Riverpod
