package com.example.prompt_guardrail

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
