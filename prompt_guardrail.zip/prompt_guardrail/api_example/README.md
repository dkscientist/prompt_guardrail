# Validation API Example

This is a reference implementation for a validation API that can be deployed separately.

## API Endpoint

**POST /validate-prompt**

### Request
```json
{
  "prompt": "What is the weather like today?"
}
```

### Response
```json
{
  "valid": true,
  "message": "Prompt is valid",
  "response": "Mock response: Your prompt is well-formed and appropriate.",
  "timestamp": "2026-02-03T18:20:00Z"
}
```

### Invalid Response
```json
{
  "valid": false,
  "message": "Prompt contains inappropriate content",
  "response": "This prompt cannot be processed due to guardrail violations.",
  "timestamp": "2026-02-03T18:20:00Z"
}
```

## Implementation Options

### 1. AWS Lambda + API Gateway
- Deploy validation logic as serverless function
- Low cost, scales automatically
- Can integrate with Bedrock Guardrails

### 2. Express.js (Node.js)
```javascript
app.post('/validate-prompt', async (req, res) => {
  const { prompt } = req.body;
  const validation = validatePrompt(prompt);
  
  if (validation.valid) {
    // Call Gemini API
    const geminiResponse = await callGemini(prompt);
    res.json({
      valid: true,
      message: validation.message,
      response: geminiResponse,
      timestamp: new Date().toISOString()
    });
  } else {
    res.json({
      valid: false,
      message: validation.message,
      response: "Prompt rejected by guardrails",
      timestamp: new Date().toISOString()
    });
  }
});
```

### 3. FastAPI (Python)
```python
@app.post("/validate-prompt")
async def validate_prompt(request: PromptRequest):
    validation = validate_prompt_logic(request.prompt)
    
    if validation["valid"]:
        gemini_response = await call_gemini(request.prompt)
        return {
            "valid": True,
            "message": validation["message"],
            "response": gemini_response,
            "timestamp": datetime.now().isoformat()
        }
    else:
        return {
            "valid": False,
            "message": validation["message"],
            "response": "Prompt rejected by guardrails",
            "timestamp": datetime.now().isoformat()
        }
```

## Current Implementation

The Flutter app currently has **client-side validation** built-in:
- `PromptValidationService` validates prompts locally
- No external API needed for basic testing
- Can be extended to call a real validation API

## To Use External API

Update `lib/services/gemini_api_service.dart` to call your validation endpoint instead of directly calling Gemini.
