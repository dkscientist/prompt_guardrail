import 'dart:convert';
import 'package:flutter/services.dart';
import '../models/app_config.dart';
import '../models/prompts_data.dart';

class ConfigService {
  static Future<AppConfig> loadAppConfig() async {
    final jsonString = await rootBundle.loadString('assets/config/app_config.json');
    final json = jsonDecode(jsonString) as Map<String, dynamic>;
    return AppConfig.fromJson(json);
  }

  static Future<PromptsData> loadPrompts() async {
    final jsonString = await rootBundle.loadString('assets/data/prompts.json');
    final json = jsonDecode(jsonString) as Map<String, dynamic>;
    return PromptsData.fromJson(json);
  }

  static Future<Map<String, dynamic>> loadMockResponses() async {
    final jsonString = await rootBundle.loadString('assets/data/mock_responses.json');
    return jsonDecode(jsonString) as Map<String, dynamic>;
  }
}
