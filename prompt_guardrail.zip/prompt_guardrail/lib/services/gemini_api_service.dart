import 'package:dio/dio.dart';

class GeminiApiService {
  final String apiKey;
  final String model;
  final int timeoutSeconds;
  late final Dio _dio;

  GeminiApiService({
    required this.apiKey,
    required this.model,
    required this.timeoutSeconds,
  }) {
    _dio = Dio(BaseOptions(
      baseUrl: 'https://generativelanguage.googleapis.com/v1beta',
      connectTimeout: Duration(seconds: timeoutSeconds),
      receiveTimeout: Duration(seconds: timeoutSeconds),
    ));
  }

  Future<String> sendPrompt(String prompt) async {
    try {
      final response = await _dio.post(
        '/models/$model:generateContent',
        queryParameters: {'key': apiKey},
        data: {
          'contents': [
            {
              'parts': [
                {'text': prompt}
              ]
            }
          ]
        },
      );

      final candidates = response.data['candidates'] as List;
      if (candidates.isEmpty) {
        throw Exception('No response from API');
      }

      final content = candidates[0]['content'];
      final parts = content['parts'] as List;
      return parts[0]['text'] as String;
    } on DioException catch (e) {
      throw Exception('API Error: ${e.message}');
    }
  }
}
