class ValidationResult {
  final bool isValid;
  final String message;

  ValidationResult({
    required this.isValid,
    required this.message,
  });
}

class PromptValidationService {
  ValidationResult validatePrompt(String prompt) {
    // Empty prompt check
    if (prompt.trim().isEmpty) {
      return ValidationResult(
        isValid: false,
        message: 'Prompt cannot be empty',
      );
    }

    // Too short
    if (prompt.trim().length < 3) {
      return ValidationResult(
        isValid: false,
        message: 'Prompt is too short',
      );
    }

    final lowerPrompt = prompt.toLowerCase();

    // Check for harmful keywords
    final harmfulKeywords = ['hack', 'illegal', 'exploit', 'crack'];
    for (final keyword in harmfulKeywords) {
      if (lowerPrompt.contains(keyword)) {
        return ValidationResult(
          isValid: false,
          message: 'Prompt contains inappropriate content',
        );
      }
    }

    // Check for vague prompts (remove punctuation for comparison)
    final cleanPrompt = lowerPrompt.replaceAll(RegExp(r'[^\w\s]'), '').trim();
    final vaguePrompts = ['help', 'do my homework', 'write something', 'what should i do'];
    if (vaguePrompts.contains(cleanPrompt)) {
      return ValidationResult(
        isValid: false,
        message: 'Prompt is too vague or unclear',
      );
    }

    // Check for nonsense - single word with no common words
    final hasSpaces = prompt.contains(' ');
    final commonWords = ['what', 'how', 'why', 'when', 'where', 'who', 'is', 'are', 'the', 'a', 'an', 'to', 'in', 'for'];
    final hasCommonWord = commonWords.any((word) => lowerPrompt.contains(word));
    
    if (!hasSpaces && !hasCommonWord) {
      return ValidationResult(
        isValid: false,
        message: 'Prompt appears to be nonsense',
      );
    }

    return ValidationResult(
      isValid: true,
      message: 'Prompt is valid',
    );
  }
}
