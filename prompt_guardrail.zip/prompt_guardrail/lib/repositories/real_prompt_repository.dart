import '../models/prompt_response.dart';
import '../services/gemini_api_service.dart';
import '../services/prompt_validation_service.dart';
import 'prompt_repository.dart';

class RealPromptRepository implements PromptRepository {
  final GeminiApiService apiService;
  final PromptValidationService validationService;

  RealPromptRepository(this.apiService)
      : validationService = PromptValidationService();

  @override
  Future<PromptResponse> sendPrompt(String prompt) async {
    final startTime = DateTime.now();
    
    // Validate prompt first
    final validation = validationService.validatePrompt(prompt);
    
    if (!validation.isValid) {
      // Don't call API if validation fails
      final endTime = DateTime.now();
      final responseTime = endTime.difference(startTime);
      
      return PromptResponse(
        prompt: prompt,
        text: 'Validation failed: ${validation.message}',
        responseTime: responseTime,
        timestamp: endTime,
        isValid: false,
        validationMessage: validation.message,
      );
    }
    
    try {
      final responseText = await apiService.sendPrompt(prompt);
      final endTime = DateTime.now();
      final responseTime = endTime.difference(startTime);

      return PromptResponse(
        prompt: prompt,
        text: responseText,
        responseTime: responseTime,
        timestamp: endTime,
        isValid: true,
        validationMessage: validation.message,
      );
    } catch (e) {
      final endTime = DateTime.now();
      final responseTime = endTime.difference(startTime);

      return PromptResponse(
        prompt: prompt,
        text: 'Error: ${e.toString()}',
        responseTime: responseTime,
        timestamp: endTime,
        isValid: true,
        validationMessage: 'Validation passed, but API call failed',
      );
    }
  }
}
