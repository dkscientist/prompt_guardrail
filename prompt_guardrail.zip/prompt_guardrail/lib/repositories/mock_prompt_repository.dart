import 'dart:math';
import '../models/prompt_response.dart';
import 'prompt_repository.dart';

class MockPromptRepository implements PromptRepository {
  final Map<String, dynamic> mockResponses;
  final Map<String, dynamic> promptResponses;
  final Random _random = Random();

  MockPromptRepository(this.mockResponses, this.promptResponses);

  @override
  Future<PromptResponse> sendPrompt(String prompt) async {
    final startTime = DateTime.now();
    
    // Simulate API delay
    await Future.delayed(const Duration(milliseconds: 800));
    
    final endTime = DateTime.now();
    final responseTime = endTime.difference(startTime);
    
    // Get response from prompt_responses mapping
    final apiResponse = promptResponses[prompt] as Map<String, dynamic>?;
    
    if (apiResponse == null) {
      throw Exception('No mock response configured for prompt: "$prompt"');
    }

    return PromptResponse(
      prompt: prompt,
      text: apiResponse['response'] as String,
      responseTime: responseTime,
      timestamp: endTime,
      isValid: apiResponse['valid'] as bool,
      validationMessage: apiResponse['message'] as String,
    );
  }
}
