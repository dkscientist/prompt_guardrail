import '../models/prompt_response.dart';

abstract class PromptRepository {
  Future<PromptResponse> sendPrompt(String prompt);
}
