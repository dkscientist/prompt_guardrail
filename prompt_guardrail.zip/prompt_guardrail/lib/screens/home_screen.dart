import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'dart:convert';
import '../providers/config_providers.dart';
import '../providers/prompt_providers.dart';
import '../widgets/prompt_list_widget.dart';
import '../widgets/categorized_prompt_list_widget.dart';
import '../widgets/response_display_widget.dart';

class HomeScreen extends ConsumerWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final promptsDataAsync = ref.watch(promptsDataProvider);
    final appConfigAsync = ref.watch(appConfigProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Prompt Guardrail'),
        elevation: 4,
        shadowColor: Colors.black26,
        automaticallyImplyLeading: false,
        actions: [
          appConfigAsync.when(
            data: (config) => Padding(
              padding: const EdgeInsets.all(16.0),
              child: Center(
                child: Text(
                  config.isMockMode ? 'MOCK' : 'REAL',
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    color: config.isMockMode ? Colors.orange : Colors.green,
                  ),
                ),
              ),
            ),
            loading: () => const SizedBox(),
            error: (_, __) => const SizedBox(),
          ),
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: () {
              Navigator.of(context).pushReplacementNamed('/');
            },
            tooltip: 'Logout',
          ),
        ],
      ),
      body: promptsDataAsync.when(
        data: (promptsData) => Column(
          children: [
            // Chat messages area
            const Expanded(
              child: ResponseDisplayWidget(),
            ),
            // Select prompt button at bottom
            _SelectPromptButton(promptsData: promptsData),
          ],
        ),
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (error, _) => Center(child: Text('Error: $error')),
      ),
    );
  }
}

class _SelectPromptButton extends ConsumerWidget {
  final dynamic promptsData;

  const _SelectPromptButton({required this.promptsData});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final chatHistory = ref.watch(chatHistoryProvider);
    
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border(top: BorderSide(color: Colors.grey[300]!)),
      ),
      child: SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                onPressed: () {
                  _showPromptSelector(context, ref, promptsData);
                },
                icon: const Icon(Icons.list),
                label: const Text('Select Prompt'),
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 16),
                ),
              ),
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: chatHistory.isEmpty
                        ? null
                        : () {
                            _showHttpDetails(context, chatHistory.last);
                          },
                    icon: const Icon(Icons.security, size: 18),
                    label: const Text('Security Scans'),
                    style: OutlinedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(vertical: 12),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () {
                      ref.read(chatHistoryProvider.notifier).clear();
                      ref.read(selectedPromptProvider.notifier).state = null;
                    },
                    icon: const Icon(Icons.add_circle_outline, size: 18),
                    label: const Text('New Session'),
                    style: OutlinedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(vertical: 12),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  void _showHttpDetails(BuildContext context, dynamic response) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => DraggableScrollableSheet(
        initialChildSize: 0.7,
        minChildSize: 0.5,
        maxChildSize: 0.95,
        expand: false,
        builder: (context, scrollController) => Container(
          decoration: const BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
          ),
          child: Column(
            children: [
              Container(
                margin: const EdgeInsets.symmetric(vertical: 12),
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                  color: Colors.grey[300],
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16.0),
                child: Row(
                  children: [
                    const Icon(Icons.security, size: 24),
                    const SizedBox(width: 8),
                    const Text(
                      'Security Scans',
                      style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                    ),
                    const Spacer(),
                    IconButton(
                      icon: const Icon(Icons.close),
                      onPressed: () => Navigator.pop(context),
                    ),
                  ],
                ),
              ),
              const Divider(),
              Expanded(
                child: SingleChildScrollView(
                  controller: scrollController,
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _buildHttpSection('Input Scan', {
                        'prompt': response.prompt,
                        'timestamp': response.timestamp.toIso8601String(),
                      }),
                      const SizedBox(height: 16),
                      _buildHttpSection('Output Scan', {
                        'valid': response.isValid,
                        'message': response.validationMessage,
                        'response': response.text,
                        'responseTime': '${response.responseTime.inMilliseconds}ms',
                      }),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildHttpSection(String title, Map<String, dynamic> data) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
          decoration: BoxDecoration(
            color: title == 'Input Scan' ? Colors.blue[100] : Colors.purple[100],
            borderRadius: BorderRadius.circular(8),
          ),
          child: Text(
            title,
            style: TextStyle(
              fontWeight: FontWeight.bold,
              fontSize: 14,
              color: title == 'Input Scan' ? Colors.blue[900] : Colors.purple[900],
            ),
          ),
        ),
        const SizedBox(height: 8),
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: Colors.black87,
            borderRadius: BorderRadius.circular(8),
          ),
          child: SelectableText(
            JsonEncoder.withIndent('  ').convert(data),
            style: const TextStyle(
              fontFamily: 'monospace',
              fontSize: 12,
              color: Colors.greenAccent,
              height: 1.5,
            ),
          ),
        ),
      ],
    );
  }

  void _showPromptSelector(BuildContext context, WidgetRef ref, dynamic promptsData) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (context) => DraggableScrollableSheet(
        initialChildSize: 0.7,
        minChildSize: 0.5,
        maxChildSize: 0.95,
        expand: false,
        builder: (context, scrollController) => Container(
          decoration: const BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
          ),
          child: Column(
            children: [
              Container(
                margin: const EdgeInsets.symmetric(vertical: 12),
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                  color: Colors.grey[300],
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              const Padding(
                padding: EdgeInsets.all(16.0),
                child: Text(
                  'Select a Prompt',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
              ),
              Expanded(
                child: DefaultTabController(
                  length: 2,
                  child: Column(
                    children: [
                      const TabBar(
                        tabs: [
                          Tab(text: 'Valid'),
                          Tab(text: 'Invalid'),
                        ],
                      ),
                      Expanded(
                        child: TabBarView(
                          children: [
                            CategorizedPromptListWidget(
                              categorizedPrompts: promptsData.validPrompts,
                              accentColor: Colors.green,
                            ),
                            CategorizedPromptListWidget(
                              categorizedPrompts: promptsData.invalidPrompts,
                              accentColor: Colors.red,
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
