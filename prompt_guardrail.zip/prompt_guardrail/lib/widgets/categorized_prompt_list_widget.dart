import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/prompts_data.dart';
import '../providers/prompt_providers.dart';

class CategorizedPromptListWidget extends ConsumerWidget {
  final Map<String, List<PromptItem>> categorizedPrompts;
  final Color accentColor;

  const CategorizedPromptListWidget({
    super.key,
    required this.categorizedPrompts,
    required this.accentColor,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final selectedPrompt = ref.watch(selectedPromptProvider);

    return ListView(
      padding: const EdgeInsets.all(8),
      children: categorizedPrompts.entries.map((entry) {
        final category = entry.key;
        final prompts = entry.value;

        return ExpansionTile(
          title: Text(
            category.toUpperCase(),
            style: const TextStyle(fontWeight: FontWeight.bold),
          ),
          initiallyExpanded: true,
          children: prompts.map((promptItem) {
            final isSelected = selectedPrompt == promptItem.prompt;
            return Card(
              margin: const EdgeInsets.symmetric(vertical: 4, horizontal: 16),
              elevation: isSelected ? 4 : 1,
              color: isSelected ? accentColor.withOpacity(0.1) : null,
              child: ListTile(
                title: Text(
                  promptItem.name.isEmpty ? '(Empty prompt)' : promptItem.name,
                  style: TextStyle(
                    fontStyle: promptItem.name.isEmpty ? FontStyle.italic : FontStyle.normal,
                    color: promptItem.name.isEmpty ? Colors.grey : null,
                  ),
                ),
                trailing: isSelected
                    ? Icon(Icons.check_circle, color: accentColor)
                    : const Icon(Icons.arrow_forward_ios, size: 16),
                onTap: () {
                  ref.read(selectedPromptProvider.notifier).state = promptItem.prompt;
                  ref.read(promptResponseProvider.notifier).sendPrompt(promptItem.prompt);
                  Navigator.pop(context);
                },
              ),
            );
          }).toList(),
        );
      }).toList(),
    );
  }
}
