import 'package:flutter_riverpod/flutter_riverpod.dart';

final showHttpRequestsProvider = StateProvider<bool>((ref) => false);
