import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/prompt_response.dart';
import '../repositories/prompt_repository.dart';
import 'config_providers.dart';

final selectedPromptProvider = StateProvider<String?>((ref) => null);

final chatHistoryProvider = StateNotifierProvider<ChatHistoryNotifier, List<PromptResponse>>((ref) {
  return ChatHistoryNotifier();
});

final currentPromptProvider = StateProvider<String?>((ref) => null);

final promptResponseProvider = StateNotifierProvider<PromptResponseNotifier, AsyncValue<PromptResponse?>>((ref) {
  return PromptResponseNotifier(ref);
});

class ChatHistoryNotifier extends StateNotifier<List<PromptResponse>> {
  ChatHistoryNotifier() : super([]);

  void addMessage(PromptResponse response) {
    state = [...state, response];
  }

  void clear() {
    state = [];
  }
}

class PromptResponseNotifier extends StateNotifier<AsyncValue<PromptResponse?>> {
  final Ref ref;

  PromptResponseNotifier(this.ref) : super(const AsyncValue.data(null));

  Future<void> sendPrompt(String prompt) async {
    // Set current prompt to show user message immediately
    ref.read(currentPromptProvider.notifier).state = prompt;
    
    state = const AsyncValue.loading();
    
    try {
      final repository = await ref.read(promptRepositoryProvider.future);
      final response = await repository.sendPrompt(prompt);
      state = AsyncValue.data(response);
      
      // Add to chat history
      ref.read(chatHistoryProvider.notifier).addMessage(response);
      
      // Clear current prompt
      ref.read(currentPromptProvider.notifier).state = null;
    } catch (e, stack) {
      state = AsyncValue.error(e, stack);
      ref.read(currentPromptProvider.notifier).state = null;
    }
  }

  void clear() {
    state = const AsyncValue.data(null);
  }
}
