import 'dart:convert';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/app_config.dart';
import '../models/prompts_data.dart';
import '../services/config_service.dart';
import '../services/gemini_api_service.dart';
import '../repositories/prompt_repository.dart';
import '../repositories/mock_prompt_repository.dart';
import '../repositories/real_prompt_repository.dart';

final appConfigProvider = FutureProvider<AppConfig>((ref) async {
  return await ConfigService.loadAppConfig();
});

final promptsDataProvider = FutureProvider<PromptsData>((ref) async {
  return await ConfigService.loadPrompts();
});

final mockResponsesProvider = FutureProvider<Map<String, dynamic>>((ref) async {
  return await ConfigService.loadMockResponses();
});

final promptResponsesProvider = FutureProvider<Map<String, dynamic>>((ref) async {
  final jsonString = await rootBundle.loadString('assets/data/prompts.json');
  final json = jsonDecode(jsonString) as Map<String, dynamic>;
  return json['prompt_responses'] as Map<String, dynamic>;
});

final promptRepositoryProvider = FutureProvider<PromptRepository>((ref) async {
  final config = await ref.watch(appConfigProvider.future);

  if (config.isMockMode) {
    final mockResponses = await ref.watch(mockResponsesProvider.future);
    final promptResponses = await ref.watch(promptResponsesProvider.future);
    return MockPromptRepository(mockResponses, promptResponses);
  } else {
    final apiService = GeminiApiService(
      apiKey: config.apiKey,
      model: config.model,
      timeoutSeconds: config.timeoutSeconds,
    );
    return RealPromptRepository(apiService);
  }
});
