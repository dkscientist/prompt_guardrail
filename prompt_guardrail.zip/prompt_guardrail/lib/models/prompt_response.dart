class PromptResponse {
  final String prompt;
  final String text;
  final Duration responseTime;
  final DateTime timestamp;
  final bool isValid;
  final String? validationMessage;

  PromptResponse({
    required this.prompt,
    required this.text,
    required this.responseTime,
    required this.timestamp,
    required this.isValid,
    this.validationMessage,
  });
}
