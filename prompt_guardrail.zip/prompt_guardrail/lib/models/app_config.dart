class AppConfig {
  final String mode;
  final String apiKey;
  final String model;
  final int timeoutSeconds;
  final String username;
  final String password;

  AppConfig({
    required this.mode,
    required this.apiKey,
    required this.model,
    required this.timeoutSeconds,
    required this.username,
    required this.password,
  });

  factory AppConfig.fromJson(Map<String, dynamic> json) {
    final auth = json['auth'] as Map<String, dynamic>;
    return AppConfig(
      mode: json['mode'] as String,
      apiKey: json['api_key'] as String,
      model: json['model'] as String,
      timeoutSeconds: json['timeout_seconds'] as int,
      username: auth['username'] as String,
      password: auth['password'] as String,
    );
  }

  bool get isMockMode => mode == 'mock';
}
