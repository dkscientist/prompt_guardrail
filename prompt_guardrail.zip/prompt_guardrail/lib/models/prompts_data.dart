class PromptItem {
  final String name;
  final String prompt;

  PromptItem({
    required this.name,
    required this.prompt,
  });

  factory PromptItem.fromJson(dynamic json) {
    if (json is String) {
      // Backward compatibility: if it's just a string, use it for both
      return PromptItem(name: json, prompt: json);
    } else if (json is Map<String, dynamic>) {
      return PromptItem(
        name: json['name'] as String,
        prompt: json['prompt'] as String,
      );
    }
    throw Exception('Invalid prompt format');
  }
}

class PromptsData {
  final Map<String, List<PromptItem>> validPrompts;
  final Map<String, List<PromptItem>> invalidPrompts;

  PromptsData({
    required this.validPrompts,
    required this.invalidPrompts,
  });

  factory PromptsData.fromJson(Map<String, dynamic> json) {
    final validPromptsJson = json['valid_prompts'];
    Map<String, List<PromptItem>> validPrompts;
    
    if (validPromptsJson is Map) {
      validPrompts = {};
      validPromptsJson.forEach((key, value) {
        validPrompts[key as String] = (value as List)
            .map((item) => PromptItem.fromJson(item))
            .toList();
      });
    } else {
      validPrompts = {'uncategorized': (validPromptsJson as List)
          .map((item) => PromptItem.fromJson(item))
          .toList()};
    }

    final invalidPromptsJson = json['invalid_prompts'];
    Map<String, List<PromptItem>> invalidPrompts;
    
    if (invalidPromptsJson is Map) {
      invalidPrompts = {};
      invalidPromptsJson.forEach((key, value) {
        invalidPrompts[key as String] = (value as List)
            .map((item) => PromptItem.fromJson(item))
            .toList();
      });
    } else {
      invalidPrompts = {'uncategorized': (invalidPromptsJson as List)
          .map((item) => PromptItem.fromJson(item))
          .toList()};
    }

    return PromptsData(
      validPrompts: validPrompts,
      invalidPrompts: invalidPrompts,
    );
  }
  
  List<PromptItem> get allValidPrompts {
    return validPrompts.values.expand((list) => list).toList();
  }
  
  List<PromptItem> get allInvalidPrompts {
    return invalidPrompts.values.expand((list) => list).toList();
  }
}
